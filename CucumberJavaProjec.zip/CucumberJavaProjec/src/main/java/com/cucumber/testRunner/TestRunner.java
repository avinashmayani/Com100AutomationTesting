package com.cucumber.testRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\main\\java\\com\\cucumber\\feature\\Application.feature", //the path of the feature files
glue={"com\\cucumber\\stepDefinition"},
dryRun = false
//the path of the step definition files

)

public class TestRunner {

}
