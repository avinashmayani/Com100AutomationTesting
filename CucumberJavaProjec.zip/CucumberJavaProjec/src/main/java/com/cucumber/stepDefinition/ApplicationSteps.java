package com.cucumber.stepDefinition;

import com.cucumber.base.BaseTest;
import com.cucumber.pages.SignInPage;
import com.cucumber.pages.ApplicationPage;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import junit.framework.Assert;

public class ApplicationSteps extends BaseTest{
	
	
	@Before
	public void openBrowser() {
		BaseTest.initBrowser();
	}

	
	  @After public void teardown() { driver.close(); }
	 
	ApplicationPage sign;
	SignInPage signclas;
	
	@Given("User is on Comm100 Home Page")
	public void user_is_on_Comm100_Home_Page() {
		String URL = prop.getProperty("ApplicationURL"); 
		driver.get(URL);

}
	@Given("User verify the Home Page")
	public void user_verify_the_Home_Page() {
	    String Actual = driver.getTitle();
	    String expected = "Customer Engagement Platform | Comm100";
	    
	    Assert.assertEquals(expected, Actual);
	    
	}

	@Then("User clicks on Login Button")
	public void user_clicks_on_Login_Button() {
		sign = new ApplicationPage();
		signclas=sign.SignIn();
		
		
	    
	}





}
