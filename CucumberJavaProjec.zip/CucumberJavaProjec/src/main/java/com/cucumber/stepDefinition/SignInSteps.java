package com.cucumber.stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cucumber.base.BaseTest;
import com.cucumber.pages.SignInPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class SignInSteps extends BaseTest {
	
	SignInPage title;
	String Actual = driver.getTitle();
	String expected = "Comm100 - User Sign In";
	
	
	@Then("User is on Sign In Page")
	public void user_is_on_Sign_In_Page() {
		
		
		
		Assert.assertEquals(expected, Actual);
		
		title = new SignInPage();
	    
	}

	@Then("User enters invalid {string} and {string}")
	public void user_enters_invalid_and(String string, String string2) {
		
		title.AddCredentials(string, string2);
		
		
	    
	}

	@Then("User Clicks on Sign In Button")
	public void user_Clicks_on_Sign_In_Button() {
		
		title.SignInbutton();
	    
	}

	
	  @Then("User is not able to sign in") public void
	  user_is_not_able_to_sign_in() {
		  
		  WebElement element = driver.findElement(By.xpath("//div[text()='Email or password is incorrect.']"));
		  String str = element.getText();
		  System.out.println(str);
	  
	  Assert.assertEquals(str, "Email or password is incorrect.");
	  
	  
	  
	  }
	 




}
