package com.cucumber.util;

public class Constants {
	
	public static final  int PAGE_LOAD_TIMEOUT = 60;
	public static final int IMPLICITLY_WAIT = 60;

}
