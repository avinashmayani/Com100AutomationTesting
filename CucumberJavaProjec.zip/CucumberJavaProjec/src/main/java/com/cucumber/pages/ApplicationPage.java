package com.cucumber.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cucumber.base.BaseTest;

public class ApplicationPage extends BaseTest {
	
	public ApplicationPage() {
		PageFactory.initElements(driver, this);
	}

	WebDriverWait wait = new WebDriverWait(driver, 30);

	@FindBy(xpath = "//a[text()='Sign In']")
	WebElement Signin;
	
	public SignInPage SignIn(){
		Signin.click(); 
		return new SignInPage();
		}

	
}