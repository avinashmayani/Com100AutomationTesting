package com.cucumber.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cucumber.base.BaseTest;

public class SignInPage extends BaseTest {
	
	public SignInPage() {
		PageFactory.initElements(driver, this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 30);
	
	@FindBy(xpath = "//input[@name= 'loginemail']")
	WebElement email;
	
	@FindBy(id = "txtPassword")
	WebElement pass;
	
	@FindBy(xpath = "//button[text()='Sign in']")
	WebElement button;
	
	public void AddCredentials(String username, String password) {
		email.sendKeys(username);
		pass.sendKeys(password);
		
	}
	public void SignInbutton(){
		button.click(); 
		}
	
	
	
	

}
